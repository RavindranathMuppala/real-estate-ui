const awsmobile = {
  "aws_project_region": "us-east-2",
  "aws_cloud_logic_custom": [
    {
      "name": "RealEstatePredictorAPI",
      "endpoint": "https://yl47kwdn47.execute-api.us-east-2.amazonaws.com/prod",
      "region": "us-east-2"
    }
  ],
};
export default awsmobile;